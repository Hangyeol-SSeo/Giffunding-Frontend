const CLIENT_ID = "a0db46eeea54f0d8265d0acb4e05b777";
const REDIRECT_URI = "http://localhost:3000/oauth/";

// export const KAKAO_AUTH_URL = "https://kauth.kakao.com/oauth/authorize?response_type=code&client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&prompt=none";


export const KAKAO_AUTH_URL = `https://kauth.kakao.com/oauth/authorize?response_type=code&client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}`;
