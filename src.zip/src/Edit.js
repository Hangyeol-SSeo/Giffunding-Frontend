import logo from './logo.svg';
import img from './img/logo_box.png';
import kakao from './img/kakao_login_medium_wide.png';
import { KAKAO_AUTH_URL } from './OAuth';
// import './login';
import {useState} from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function Edit() {
  return (
    <div>
        edit 화면입니다
        {/* <div class="top_progress_bar">
            <table>
                <tr>
                    <td style="width: 42%;"></td>
                    <td style="width: 1%; background-color: #fff2df;"></td>
                    <td style="width: 42%; background-color: #f6dcdc;"></td>
                </tr>
            </table>
        </div>
        <div class="draw_explain">
            선물을 그려주세요!
        </div>
        <div class="user_input">
            <div id="input_picture">
                <canvas id="myCanvas"></canvas>
            </div>
            <div id="present_title">
                <b>선물 이름</b>
            </div>
            <div id="input_name">
                <input type="text" placeholder="(0/8)"/>
            </div>
            <div id="price">
                <b>가격</b>
            </div>
            <div id="input_price">
                <input type="text" placeholder="원"/>
            </div>
            <div id="information">
                <b>펀딩에 참여하는 친구는<br/>
                한 사람당 가상의 돈 10만원이 주어집니다.</b>
            </div>
        </div>
        <div class="page_move">
            <button id="back">이전</button>
            <button id="next">다음</button>
        </div>
        <script src="C:\workspace\giffunding\js\canvas.js"></script> */}
    </div>
  );
}
export default Edit;